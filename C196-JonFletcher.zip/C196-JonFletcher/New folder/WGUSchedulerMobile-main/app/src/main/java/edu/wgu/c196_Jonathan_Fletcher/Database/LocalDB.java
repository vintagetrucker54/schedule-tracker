package edu.wgu.c196_Jonathan_Fletcher.Database;

import android.content.Context;

import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import edu.wgu.c196_Jonathan_Fletcher.DAO.AssessmentDAO;
import edu.wgu.c196_Jonathan_Fletcher.DAO.CourseDAO;
import edu.wgu.c196_Jonathan_Fletcher.DAO.CourseMentorDAO;
import edu.wgu.c196_Jonathan_Fletcher.DAO.TermDAO;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Assessment;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Course;
import edu.wgu.c196_Jonathan_Fletcher.Entity.CourseMentor;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Term;
import edu.wgu.c196_Jonathan_Fletcher.Utilities.Converters;

@androidx.room.Database(entities = {Term.class, Course.class, CourseMentor.class, Assessment.class}, exportSchema = false, version = 5)
@TypeConverters({Converters.class})
public abstract class LocalDB extends RoomDatabase {

    private static final String DB_Name = "c196_JF.db";
    private static LocalDB instance;

    public static synchronized LocalDB getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(), LocalDB.class, DB_Name).allowMainThreadQueries().fallbackToDestructiveMigration().build();
        }
        return instance;
    }

    public abstract TermDAO termDao();

    public abstract CourseDAO courseDao();

    public abstract CourseMentorDAO courseMentorDao();

    public abstract AssessmentDAO assessmentDao();
}
