package edu.wgu.c196_Jonathan_Fletcher.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import edu.wgu.c196_Jonathan_Fletcher.Database.LocalDB;
import edu.wgu.c196_Jonathan_Fletcher.Entity.CourseMentor;
import edu.wgu.c196_Jonathan_Fletcher.R;

public class EditMentor extends AppCompatActivity {
    LocalDB db;
    boolean mentorDEL;
    boolean mentorUpdate;
    ExtendedFloatingActionButton updateMentor_BTN;
    EditText eMentorEmail;
    EditText eMentorName;
    EditText eMentorPhone;
    int courseID;
    Intent intent;
    int mentorID;
    int termID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_mentor);
        intent = getIntent();
        db = LocalDB.getInstance(getApplicationContext());
        termID = intent.getIntExtra("termID", -1);
        courseID = intent.getIntExtra("courseID", -1);
        mentorID = intent.getIntExtra("mentorID", -1);
        eMentorName = findViewById(R.id.editMentorName);
        eMentorPhone = findViewById(R.id.editMentorPhone);
        eMentorEmail = findViewById(R.id.editMentorEmailAddress);
        updateMentor_BTN = findViewById(R.id.updateMentorFAB);

        setValues();

        updateMentor_BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateMentor();

                if (mentorUpdate) {
                    Intent intent = new Intent(getApplicationContext(), MentorDetails.class);
                    intent.putExtra("termID", termID);
                    intent.putExtra("courseID", courseID);
                    intent.putExtra("mentorID", mentorID);
                    startActivity(intent);
                }
            }
        });
    }

    private void setValues() {
        CourseMentor mentor = new CourseMentor();
        mentor = db.courseMentorDao().getMentor(courseID, mentorID);
        String name = mentor.getMentor_name();
        String phone = mentor.getMentor_phone();
        String email = mentor.getMentor_email();

        eMentorName.setText(name);
        eMentorPhone.setText(phone);
        eMentorEmail.setText(email);
    }

    private void updateMentor() {
        String name = eMentorName.getText().toString();
        String phone = eMentorPhone.getText().toString();
        String email = eMentorEmail.getText().toString();

        if (name.trim().isEmpty()) {
            Toast.makeText(this, "Name is required", Toast.LENGTH_SHORT).show();
            return;
        }
        if (phone.trim().isEmpty()) {
            Toast.makeText(this, "Number is required", Toast.LENGTH_SHORT).show();
            return;
        }
        if (email.trim().isEmpty()) {
            Toast.makeText(this, "Email is required", Toast.LENGTH_SHORT).show();
            return;
        }

        CourseMentor mentor = new CourseMentor();
        mentor.setCourse_id_fk(courseID);
        mentor.setMentor_id(mentorID);
        mentor.setMentor_name(name);
        mentor.setMentor_phone(phone);
        mentor.setMentor_email(email);
        db.courseMentorDao().updateMentor(mentor);
        Toast.makeText(this, name + " has been updated", Toast.LENGTH_SHORT).show();
        mentorUpdate = true;
    }

    private void deleteMentor() {
        CourseMentor mentor = new CourseMentor();
        mentor = db.courseMentorDao().getMentor(courseID, mentorID);
        db.courseMentorDao().deleteMentor(mentor);
        Toast.makeText(this, "Mentor has been deleted", Toast.LENGTH_SHORT).show();
        mentorDEL = true;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.delete_mentor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.deleteMentorIC:
                deleteMentor();
                Intent intent = new Intent(getApplicationContext(), CourseDetails.class);
                intent.putExtra("termID", termID);
                intent.putExtra("courseID", courseID);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}