package edu.wgu.c196_Jonathan_Fletcher.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import edu.wgu.c196_Jonathan_Fletcher.Database.LocalDB;
import edu.wgu.c196_Jonathan_Fletcher.Entity.CourseMentor;
import edu.wgu.c196_Jonathan_Fletcher.R;

public class MentorDetails extends AppCompatActivity {
    LocalDB db;
    int termID;
    int courseID;
    int mentorID;
    Intent intent;
    TextView mentorName;
    TextView mentorPhone;
    TextView mentorEmail;
    ExtendedFloatingActionButton edit_BTN;
    boolean mentorDEL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mentor_details);
        intent = getIntent();
        db = LocalDB.getInstance(getApplicationContext());
        termID = intent.getIntExtra("termID", -1);
        courseID = intent.getIntExtra("courseID", -1);
        mentorID = intent.getIntExtra("mentorID", -1);
        mentorName = findViewById(R.id.mdName);
        mentorPhone = findViewById(R.id.mdPhone);
        mentorEmail = findViewById(R.id.mdEmail);
        edit_BTN = findViewById(R.id.mdEditFAB);

        setValues();

        edit_BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), EditMentor.class);
                intent.putExtra("termID", termID);
                intent.putExtra("courseID", courseID);
                intent.putExtra("mentorID", mentorID);
                startActivity(intent);
            }
        });

    }

    private void deleteMentor() {
        CourseMentor mentor = new CourseMentor();
        mentor = db.courseMentorDao().getMentor(courseID, mentorID);
        db.courseMentorDao().deleteMentor(mentor);
        Toast.makeText(this, "Mentor has been deleted", Toast.LENGTH_SHORT).show();
        mentorDEL = true;
    }

    private void setValues() {
        CourseMentor mentor = new CourseMentor();
        mentor = db.courseMentorDao().getMentor(courseID, mentorID);
        String name = mentor.getMentor_name();
        String phone = mentor.getMentor_phone();
        String email = mentor.getMentor_email();

        mentorName.setText(name);
        mentorPhone.setText(phone);
        mentorEmail.setText(email);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.delete_mentor, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.deleteMentorIC:
                deleteMentor();
                Intent intent = new Intent(getApplicationContext(), CourseDetails.class);
                intent.putExtra("termID", termID);
                intent.putExtra("courseID", courseID);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}