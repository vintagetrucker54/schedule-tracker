package edu.wgu.c196_Jonathan_Fletcher.Activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.List;

import edu.wgu.c196_Jonathan_Fletcher.Database.LocalDB;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Assessment;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Course;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Term;
import edu.wgu.c196_Jonathan_Fletcher.R;
import edu.wgu.c196_Jonathan_Fletcher.Utilities.AddSampleData;

public class HomePage extends AppCompatActivity {
    LocalDB db;
    TextView termData;
    TextView cPendingTxt;
    TextView cCompletedTxt;
    TextView cDroppedTxt;
    TextView aPendingTxt;
    TextView aPassedTxt;
    TextView aFailedTxt;
    ExtendedFloatingActionButton termList_BTN;


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = LocalDB.getInstance(getApplicationContext());
        termData = findViewById(R.id.termData);
        cPendingTxt = findViewById(R.id.coursesPendingTextView);
        cCompletedTxt = findViewById(R.id.coursesCompletedTextView);
        cDroppedTxt = findViewById(R.id.coursesDroppedTextView);
        aPendingTxt = findViewById(R.id.assessmentsPendingTextView);
        aPassedTxt = findViewById(R.id.assessmentsPassedTextView);
        aFailedTxt = findViewById(R.id.assessmentsFailedTextView);
        termList_BTN = findViewById(R.id.hTermListFAB);

        updateViews();
        termList_BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), TermList.class);
                startActivity(intent);
            }
        });
    }


    private void updateViews() {
        int term = 0;
        int termComplete = 0;
        int termPending = 0;
        int course = 0;
        int assessment = 0;
        int coursesPending = 0;
        int coursesCompleted = 0;
        int coursesDropped = 0;
        int assessmentsPending = 0;
        int assessmentsPassed = 0;
        int assessmentsFailed = 0;

        try {
            List<Term> termList = db.termDao().getAllTerms();
            List<Course> courseList = db.courseDao().getAllCourses();
            List<Assessment> assessmentList = db.assessmentDao().getAllAssessments();

            try {
                for (int i = 0; i < termList.size(); i++) {
                    term = termList.size();
                    if (termList.get(i).getTerm_status().contains("Completed")) termComplete++;
                    if (termList.get(i).getTerm_status().contains("In-Progress")) termPending++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                for (int i = 0; i < courseList.size(); i++) {
                    course = courseList.size();
                    if (courseList.get(i).getCourse_status().contains("Pending")) coursesPending++;
                    if (courseList.get(i).getCourse_status().contains("In-Progress"))
                        coursesPending++;
                    if (courseList.get(i).getCourse_status().contains("Completed"))
                        coursesCompleted++;
                    if (courseList.get(i).getCourse_status().contains("Dropped")) coursesDropped++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                for (int i = 0; i < assessmentList.size(); i++) {
                    assessment = assessmentList.size();
                    if (assessmentList.get(i).getAssessment_status().contains("Pending"))
                        assessmentsPending++;
                    if (assessmentList.get(i).getAssessment_status().contains("Passed"))
                        assessmentsPassed++;
                    if (assessmentList.get(i).getAssessment_status().contains("Failed"))
                        assessmentsFailed++;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        termData.setText(String.valueOf(term));
        cPendingTxt.setText(String.valueOf(coursesPending));
        cCompletedTxt.setText(String.valueOf(coursesCompleted));
        cDroppedTxt.setText(String.valueOf(coursesDropped));
        aPendingTxt.setText(String.valueOf(assessmentsPending));
        aFailedTxt.setText(String.valueOf(assessmentsFailed));
        aPassedTxt.setText(String.valueOf(assessmentsPassed));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateViews();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.home_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.populateDBMenu:
                AddSampleData addSampleData = new AddSampleData();
                addSampleData.populate(getApplicationContext());
                updateViews();
                Toast.makeText(this, "LocalDB Populated", Toast.LENGTH_SHORT);
                return true;
            case R.id.resetDBMenu:
                db.clearAllTables();
                updateViews();
                Toast.makeText(this, "LocalDB Reset", Toast.LENGTH_SHORT);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}