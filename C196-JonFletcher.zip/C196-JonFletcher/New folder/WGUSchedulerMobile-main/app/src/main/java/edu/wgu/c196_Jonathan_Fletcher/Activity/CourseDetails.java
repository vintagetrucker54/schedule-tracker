package edu.wgu.c196_Jonathan_Fletcher.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import edu.wgu.c196_Jonathan_Fletcher.Database.LocalDB;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Assessment;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Course;
import edu.wgu.c196_Jonathan_Fletcher.Entity.CourseMentor;
import edu.wgu.c196_Jonathan_Fletcher.R;

public class CourseDetails extends AppCompatActivity {
    LocalDB db;
    Intent intent;
    int courseID;
    int termID;
    ListView cdMentorList;//TODO REFACTOR
    ListView cdAssessmentList;//TODO REFACTOR
    List<CourseMentor> allMentors;//TODO REFACTOR
    List<Assessment> allAssessments;//TODO REFACTOR
    FloatingActionButton cdAddMentorFAB;//TODO REFACTOR
    FloatingActionButton cdAddAssessmentFAB;//TODO REFACTOR
    TextView cdName;//TODO REFACTOR
    TextView cdStatus;//TODO REFACTOR
    TextView cdAlert;//TODO REFACTOR
    TextView cdsDate;//TODO REFACTOR
    TextView cdeDate;//TODO REFACTOR
    TextView cdNotes;//TODO REFACTOR

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);
        intent = getIntent();
        db = LocalDB.getInstance(getApplicationContext());
        termID = intent.getIntExtra("termID", -1);
        courseID = intent.getIntExtra("courseID", -1);
        cdMentorList = findViewById(R.id.cdMentorList);
        cdAssessmentList = findViewById(R.id.cdAssessmentList);
        cdAddMentorFAB = findViewById(R.id.cdAddMentorFAB);
        cdAddAssessmentFAB = findViewById(R.id.cdAddAssessmentFAB);
        cdName = findViewById(R.id.cdName);
        cdStatus = findViewById(R.id.cdStatus);
        cdAlert = findViewById(R.id.cdAlert);
        cdsDate = findViewById(R.id.cdSdate);
        cdeDate = findViewById(R.id.cdEdate);
        cdNotes = findViewById(R.id.cdNotes);

        setValues();
        updateLists();

        //Mentors
        cdAddMentorFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddMentor.class);
                intent.putExtra("termID", termID);
                intent.putExtra("courseID", courseID);
                startActivity(intent);
            }
        });

        cdMentorList.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(getApplicationContext(), MentorDetails.class);
            intent.putExtra("termID", termID);
            intent.putExtra("courseID", courseID);
            intent.putExtra("mentorID", allMentors.get(position).getMentor_id());
            startActivity(intent);
            System.out.println(id);
        });

        //Assessments
        cdAddAssessmentFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddAssessment.class);
                intent.putExtra("termID", termID);
                intent.putExtra("courseID", courseID);
                startActivity(intent);
            }
        });

        cdAssessmentList.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(getApplicationContext(), AssessmentDetails.class);
            intent.putExtra("termID", termID);
            intent.putExtra("courseID", courseID);
            intent.putExtra("assessmentID", allAssessments.get(position).getAssessment_id());
            startActivity(intent);
            System.out.println(id);
        });

    }

    private void setValues() {
        Course course = new Course();
        course = db.courseDao().getCourse(termID, courseID);
        String name = course.getCourse_name();
        String status = course.getCourse_status();
        boolean alert1 = course.getCourse_alert();
        String sDate = DateFormat.format("MM/dd/yyyy", course.getCourse_start()).toString();
        String eDate = DateFormat.format("MM/dd/yyyy", course.getCourse_end()).toString();
        String notes = course.getCourse_notes();
        String alert = "Off";
        if (alert1) {
            alert = "On";
        }
        cdName.setText(name);
        cdStatus.setText(status);
        cdAlert.setText(alert);
        cdsDate.setText(sDate);
        cdeDate.setText(eDate);
        cdNotes.setText(notes);
    }

    private void updateLists() {
        List<CourseMentor> allMentors = db.courseMentorDao().getMentorList(courseID);
        ArrayAdapter<CourseMentor> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, allMentors);
        cdMentorList.setAdapter(adapter);
        this.allMentors = allMentors;

        adapter.notifyDataSetChanged();

        List<Assessment> allAssessments = db.assessmentDao().getAssessmentList(courseID);
        ArrayAdapter<Assessment> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, allAssessments);
        cdAssessmentList.setAdapter(adapter2);
        this.allAssessments = allAssessments;
        adapter2.notifyDataSetChanged();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.edit_course, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.tdEditCourseIC:
                Intent intent = new Intent(getApplicationContext(), EditCourse.class);
                intent.putExtra("termID", termID);
                intent.putExtra("courseID", courseID);
                intent.putExtra("mentorList", allMentors.size());
                intent.putExtra("assessmentList", allAssessments.size());
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}