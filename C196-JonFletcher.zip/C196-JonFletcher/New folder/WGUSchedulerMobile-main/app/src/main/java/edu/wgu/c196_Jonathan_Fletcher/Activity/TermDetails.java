package edu.wgu.c196_Jonathan_Fletcher.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.List;

import edu.wgu.c196_Jonathan_Fletcher.Database.LocalDB;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Course;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Term;
import edu.wgu.c196_Jonathan_Fletcher.R;

public class TermDetails extends AppCompatActivity {
    LocalDB db;
    ExtendedFloatingActionButton addClass_BTN;
    Intent intent;
    int termID;
    List<Course> allCourses;
    ListView classList;
    TextView tdeDate;//TODO REFACTOR
    TextView name;
    TextView startDate;
    TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_details);
        intent = getIntent();
        classList = findViewById(R.id.tdClassList);
        db = LocalDB.getInstance(getApplicationContext());
        termID = intent.getIntExtra("termID", -1);
        name = findViewById(R.id.tdName);
        status = findViewById(R.id.tdStatus);
        name = findViewById(R.id.tdName);
        startDate = findViewById(R.id.tdSdate);
        tdeDate = findViewById((R.id.tdEdate));
        addClass_BTN = findViewById(R.id.tdAddClassFAB);
        updateClassList();
        setValues();
        addClass_BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddCourse.class);
                intent.putExtra("termID", termID);
                startActivity(intent);
            }
        });
        classList.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(getApplicationContext(), CourseDetails.class);
            intent.putExtra("termID", termID);
            intent.putExtra("courseID", allCourses.get(position).getCourse_id());
            startActivity(intent);
            System.out.println(id);
        });

    }

    private void setValues() {

        Term term = new Term();
        term = db.termDao().getTerm(termID);
        String name = term.getTerm_name();
        String status = term.getTerm_status();
        String sDate = DateFormat.format("MM/dd/yyyy", term.getTerm_start()).toString();
        String eDate = DateFormat.format("MM/dd/yyyy", term.getTerm_end()).toString();
        this.name.setText(name);
        this.status.setText(status);
        startDate.setText(sDate);
        tdeDate.setText(eDate);
    }

    private void updateClassList() {
        List<Course> allCourses = db.courseDao().getCourseList(termID);
        ArrayAdapter<Course> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, allCourses);
        classList.setAdapter(adapter);
        this.allCourses = allCourses;

        adapter.notifyDataSetChanged();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.edit_term, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.tdEditTermFAB:
                Intent intent = new Intent(getApplicationContext(), EditTerm.class);
                intent.putExtra("termID", termID);
                intent.putExtra("courseList", allCourses.size());
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}

