package edu.wgu.c196_Jonathan_Fletcher.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.List;

import edu.wgu.c196_Jonathan_Fletcher.Database.LocalDB;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Term;
import edu.wgu.c196_Jonathan_Fletcher.R;

public class TermList extends AppCompatActivity {
    LocalDB db;
    ExtendedFloatingActionButton addTerm_BTN;
    List<Term> allTerms;
    ListView termList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term_list);
        termList = findViewById(R.id.tdTermList);
        db = LocalDB.getInstance(getApplicationContext());
        addTerm_BTN = findViewById(R.id.addTermFAB);

        termList.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(getApplicationContext(), TermDetails.class);
            intent.putExtra("termID", allTerms.get(position).getTerm_id());
            startActivity(intent);
            System.out.println(id);
        });

        updateTermList();

        addTerm_BTN.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), AddTerm.class);
            startActivity(intent);
        });
    }

    private void updateTermList() {
        List<Term> allTerms = db.termDao().getTermList();
        ArrayAdapter<Term> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, allTerms);
        termList.setAdapter(adapter);
        this.allTerms = allTerms;

        adapter.notifyDataSetChanged();
    }
}