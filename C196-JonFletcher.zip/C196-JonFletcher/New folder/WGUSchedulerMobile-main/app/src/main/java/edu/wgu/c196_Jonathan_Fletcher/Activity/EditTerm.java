package edu.wgu.c196_Jonathan_Fletcher.Activity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import edu.wgu.c196_Jonathan_Fletcher.Database.LocalDB;
import edu.wgu.c196_Jonathan_Fletcher.Entity.Term;
import edu.wgu.c196_Jonathan_Fletcher.R;
import edu.wgu.c196_Jonathan_Fletcher.Utilities.DatePickerFragment;

public class EditTerm extends AppCompatActivity implements DatePickerDialog.OnDateSetListener {
    LocalDB db;
    boolean termDEL;
    boolean termUpdate;
    EditText eTermName;
    ExtendedFloatingActionButton updateTerm_BTN;
    int courseList;
    Intent intent;
    int termID;
    SimpleDateFormat formatter;
    Spinner eTermStatus;
    String status;
    TextView eTermStart;
    TextView eTermEnd;
    private TextView datePickerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_term);
        intent = getIntent();
        db = LocalDB.getInstance(getApplicationContext());
        termID = intent.getIntExtra("termID", -1);
        courseList = intent.getIntExtra("courseList", -1);
        eTermName = findViewById(R.id.editTermName);
        eTermStatus = findViewById(R.id.editTermStatus);
        eTermStart = findViewById(R.id.editSDateTerm);
        eTermEnd = findViewById(R.id.editEDateTerm);
        updateTerm_BTN = findViewById(R.id.updateTermFAB);

        setupDatePicker();

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.term_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        eTermStatus.setAdapter(adapter);

        eTermStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                status = eTermStatus.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        setValues();
        updateTerm_BTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    updateTerm();
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                if (termUpdate) {
                    Intent intent = new Intent(getApplicationContext(), TermDetails.class);
                    intent.putExtra("termID", termID);
                    startActivity(intent);
                }
            }
        });
    }

    private void setValues() {
        Term term = new Term();
        term = db.termDao().getTerm(termID);
        String name = term.getTerm_name();
        String status = term.getTerm_status();
        String sDate = DateFormat.format("MM/dd/yyyy", term.getTerm_start()).toString();
        String eDate = DateFormat.format("MM/dd/yyyy", term.getTerm_end()).toString();

        eTermName.setText(name);
        eTermStatus.setSelection(getIndex(eTermStatus, status));
        eTermStart.setText(sDate);
        eTermEnd.setText(eDate);
    }

    private int getIndex(Spinner spinner, String myString) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(myString)) {
                return i;
            }
        }
        return 0;
    }

    private void deleteTerm() {
        if (courseList > 0) {
            Toast.makeText(this, "Cant delete a term with associated courses", Toast.LENGTH_SHORT).show();
            return;
        }

        Term term = new Term();
        term = db.termDao().getTerm(termID);
        db.termDao().deleteTerm(term);
        Toast.makeText(this, "Term has been deleted", Toast.LENGTH_SHORT).show();
        termDEL = true;
    }

    private void updateTerm() throws ParseException {
        formatter = new SimpleDateFormat("MM/dd/yyyy");
        String name = eTermName.getText().toString();
        String sDate = eTermStart.getText().toString();
        String eDate = eTermEnd.getText().toString();
        Date stDate = formatter.parse(sDate);
        Date enDate = formatter.parse(eDate);

        if (name.trim().isEmpty()) {
            Toast.makeText(this, "Name is required", Toast.LENGTH_SHORT).show();
            return;
        }
        if (stDate.after(enDate)) {
            Toast.makeText(this, "Start date cant be after the end date", Toast.LENGTH_SHORT).show();
            return;
        }
        if (sDate.trim().isEmpty()) {
            Toast.makeText(this, "Start date is required", Toast.LENGTH_SHORT).show();
            return;
        }
        if (eDate.trim().isEmpty()) {
            Toast.makeText(this, "End date is required", Toast.LENGTH_SHORT).show();
            return;
        }


        Term term = new Term();
        term.setTerm_id(termID);
        term.setTerm_name(name);
        term.setTerm_status(status);
        term.setTerm_start(stDate);
        term.setTerm_end(enDate);
        db.termDao().updateTerm(term);
        Toast.makeText(this, "Term has been updated.", Toast.LENGTH_SHORT).show();
        termUpdate = true;
    }

    private void setupDatePicker() {

        eTermStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerView = findViewById(R.id.editSDateTerm);
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
            }
        });

        eTermEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerView = findViewById(R.id.editEDateTerm);
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
            }
        });
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month = month + 1);
        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        String currentDateString = month + "/" + dayOfMonth + "/" + year;
        datePickerView.setText(currentDateString);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.delete_term, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.deleteTermIC:
                deleteTerm();
                Intent intent = new Intent(getApplicationContext(), TermList.class);
                intent.putExtra("termID", termID);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}